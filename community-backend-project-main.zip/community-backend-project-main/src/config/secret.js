module.exports.JWT_SECRET = "maikyubatau";
// module.exports = JWT_SECRET;